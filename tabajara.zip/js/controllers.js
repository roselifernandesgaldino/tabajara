angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('contatoCtrl', function($scope) {

})
   
.controller('produtoCtrl', function($scope) {

})
    